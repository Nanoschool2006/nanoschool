# NSTC AI Education Platform

## Overview

This is a modern, SEO-optimized AI education homepage for NSTC (Nano Science Technology Consortium), featuring comprehensive artificial intelligence courses, workshops, and training programs. The application showcases real participant analytics from 13,534+ enrolled students across 20+ countries and provides advanced styling with AI-themed design elements targeting top SERP rankings.

## Recent Changes (July 23, 2025)

- **Enhanced SEO Optimization**: Added comprehensive meta tags, structured data (Educational Organization + FAQ), and AI-focused keywords for 2025 SERP ranking
- **Real Analytics Integration**: Created participant analytics section using actual Formidable XML data showing global reach, education levels, and experience distribution
- **Advanced UI/UX**: Implemented gradient animations, glassmorphism effects, and AI-themed color palette with improved text contrast
- **Comprehensive Course Showcase**: Added detailed AI course sections with professional tracks, machine learning mastery, and generative AI programs
- **Global Impact Visualization**: Interactive analytics showing geographic distribution, education backgrounds, and participant demographics
- **WordPress Integration Ready**: Maintained Formidable shortcode compatibility for workshop, mentor, and testimonial sections

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a monorepo structure with clear separation between client and server code:

- **Frontend**: React with TypeScript, using Vite as the build tool
- **Backend**: Express.js with TypeScript running on Node.js
- **Database**: PostgreSQL with Drizzle ORM
- **UI Framework**: Shadcn/ui components with Tailwind CSS
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing

## Key Components

### Frontend Architecture
- **React 18** with TypeScript for type safety
- **Vite** for fast development and optimized builds
- **Shadcn/ui** component library built on Radix UI primitives
- **Tailwind CSS** for utility-first styling with custom AI-themed color palette
- **TanStack Query** for efficient server state management and caching
- **Wouter** for lightweight client-side routing

### Backend Architecture
- **Express.js** server with TypeScript
- **Drizzle ORM** for database operations with PostgreSQL
- **Session-based** architecture (connect-pg-simple for session storage)
- **RESTful API** structure with `/api` prefix
- **Development/Production** environment handling

### Database Layer
- **PostgreSQL** as the primary database
- **Drizzle ORM** for type-safe database operations
- **Schema-first** approach with shared type definitions
- **Migration system** using drizzle-kit

### UI Components
- Comprehensive set of reusable components from Shadcn/ui
- Custom AI-themed styling with CSS variables
- Mobile-responsive design patterns
- Accessibility-first approach with Radix UI primitives

## Data Flow

1. **Client Requests**: React components make API calls using TanStack Query
2. **API Layer**: Express.js routes handle requests under `/api` prefix
3. **Business Logic**: Server-side logic processes requests and interacts with storage
4. **Data Storage**: Drizzle ORM manages database operations with PostgreSQL
5. **Response**: JSON responses sent back to client with proper error handling

The application uses a storage interface pattern that currently implements in-memory storage but can be easily swapped for database persistence.

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity
- **drizzle-orm**: Type-safe ORM for database operations
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Headless UI components for accessibility
- **tailwindcss**: Utility-first CSS framework

### Development Tools
- **tsx**: TypeScript execution for development
- **esbuild**: Fast JavaScript bundler for production builds
- **drizzle-kit**: Database migration and introspection tools

### UI Enhancement
- **lucide-react**: Icon library
- **class-variance-authority**: Utility for conditional CSS classes
- **embla-carousel-react**: Carousel component functionality

## Deployment Strategy

### Build Process
1. **Frontend Build**: Vite compiles React app to static assets in `dist/public`
2. **Backend Build**: esbuild bundles server code to `dist/index.js`
3. **Database Setup**: Drizzle migrations ensure schema consistency

### Environment Configuration
- **Development**: Uses `tsx` for hot reloading with Vite middleware
- **Production**: Serves built static files with Express
- **Database**: Configured via `DATABASE_URL` environment variable

### Hosting Considerations
- Static assets served from `dist/public`
- Server runs on configurable port with fallback routing
- Database migrations handled via `db:push` script
- Environment-specific optimizations for Replit deployment

The application is designed to be deployment-ready for platforms like Replit, with proper error handling, logging, and environment-specific configurations.