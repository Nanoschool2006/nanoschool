import { useState, useEffect } from "react";
import { Brain, GraduationCap, Users, Calendar, Award, ChevronRight, Menu, X, Play, Phone, ExternalLink, Signal, BookOpen, Globe, Briefcase, Bot, Wand2, Gavel, Stethoscope, Presentation, Calculator, Heart, Cog, Database, Eye, MessageSquare, List, HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function Home() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      {/* Navigation */}
      <nav 
        className={`fixed w-full z-50 transition-all duration-300 ${
          isScrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-white/90 backdrop-blur-md'
        } border-b border-gray-200`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-ai-blue to-ai-purple rounded-xl flex items-center justify-center">
                <Brain className="text-white text-xl" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-ai-blue">NSTC</h1>
                <p className="text-xs text-gray-600">AI Education Hub</p>
              </div>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden lg:flex items-center space-x-8">
              <button 
                onClick={() => scrollToSection('courses')} 
                className="text-gray-700 hover:text-ai-blue transition-colors duration-300 font-medium"
              >
                AI Courses
              </button>
              <button 
                onClick={() => scrollToSection('workshops')} 
                className="text-gray-700 hover:text-ai-blue transition-colors duration-300 font-medium"
              >
                Workshops
              </button>
              <button 
                onClick={() => scrollToSection('mentors')} 
                className="text-gray-700 hover:text-ai-blue transition-colors duration-300 font-medium"
              >
                Expert Mentors
              </button>
              <button 
                onClick={() => scrollToSection('testimonials')} 
                className="text-gray-700 hover:text-ai-blue transition-colors duration-300 font-medium"
              >
                Success Stories
              </button>
              <button 
                onClick={() => scrollToSection('programs')} 
                className="text-gray-700 hover:text-ai-blue transition-colors duration-300 font-medium"
              >
                All Programs
              </button>
              <Button className="bg-gradient-to-r from-ai-blue to-ai-purple text-white px-6 py-2 rounded-lg font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-300">
                Start Learning
              </Button>
            </div>
            
            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden text-gray-700 hover:text-ai-blue"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X /> : <Menu />}
            </Button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden bg-white border-t border-gray-200">
            <div className="px-4 py-6 space-y-4">
              <button 
                onClick={() => scrollToSection('courses')} 
                className="block text-gray-700 hover:text-ai-blue transition-colors duration-300 font-medium"
              >
                AI Courses
              </button>
              <button 
                onClick={() => scrollToSection('workshops')} 
                className="block text-gray-700 hover:text-ai-blue transition-colors duration-300 font-medium"
              >
                Workshops
              </button>
              <button 
                onClick={() => scrollToSection('mentors')} 
                className="block text-gray-700 hover:text-ai-blue transition-colors duration-300 font-medium"
              >
                Expert Mentors
              </button>
              <button 
                onClick={() => scrollToSection('testimonials')} 
                className="block text-gray-700 hover:text-ai-blue transition-colors duration-300 font-medium"
              >
                Success Stories
              </button>
              <button 
                onClick={() => scrollToSection('programs')} 
                className="block text-gray-700 hover:text-ai-blue transition-colors duration-300 font-medium"
              >
                All Programs
              </button>
              <Button className="w-full bg-gradient-to-r from-ai-blue to-ai-purple text-white px-6 py-3 rounded-lg font-semibold">
                Start Learning
              </Button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
        {/* Animated Background */}
        <div className="absolute inset-0 gradient-animation opacity-90"></div>
        <div className="absolute inset-0 bg-black/20"></div>
        
        {/* Floating AI Elements */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-white/10 rounded-full animate-float hidden lg:block"></div>
        <div className="absolute top-40 right-20 w-32 h-32 bg-white/5 rounded-full animate-float" style={{animationDelay: '-2s'}}></div>
        <div className="absolute bottom-40 left-20 w-16 h-16 bg-white/15 rounded-full animate-float" style={{animationDelay: '-4s'}}></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="mb-8">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 text-shadow">
              Master <span className="text-ai-amber">Artificial Intelligence</span><br />
              Transform Your Future
            </h1>
            <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-4xl mx-auto leading-relaxed">
              Join the AI revolution with NSTC's comprehensive training programs. From beginner to expert, unlock the power of machine learning, deep learning, and generative AI technologies.
            </p>
          </div>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button 
              onClick={() => scrollToSection('courses')}
              className="bg-white text-ai-blue px-8 py-4 rounded-lg font-bold text-lg hover:bg-gray-100 transform hover:scale-105 transition-all duration-300 shadow-xl"
            >
              <Play className="mr-2" />
              Explore AI Courses
            </Button>
            <Button 
              variant="ghost"
              className="glassmorphism text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-white/20 transform hover:scale-105 transition-all duration-300"
            >
              <Calendar className="mr-2" />
              Book Free Consultation
            </Button>
          </div>
          
          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            <Card className="glassmorphism rounded-xl text-center border-white/20">
              <CardContent className="p-6">
                <div className="text-3xl font-bold text-white mb-2">13,534+</div>
                <div className="text-white/90 font-medium">Students Trained</div>
              </CardContent>
            </Card>
            <Card className="glassmorphism rounded-xl text-center border-white/20">
              <CardContent className="p-6">
                <div className="text-3xl font-bold text-white mb-2">20+</div>
                <div className="text-white/90 font-medium">Countries Reached</div>
              </CardContent>
            </Card>
            <Card className="glassmorphism rounded-xl text-center border-white/20">
              <CardContent className="p-6">
                <div className="text-3xl font-bold text-white mb-2">200+</div>
                <div className="text-white/90 font-medium">Expert Mentors</div>
              </CardContent>
            </Card>
            <Card className="glassmorphism rounded-xl text-center border-white/20">
              <CardContent className="p-6">
                <div className="text-3xl font-bold text-white mb-2">98%</div>
                <div className="text-white/90 font-medium">Success Rate</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* AI Courses Section */}
      <section id="courses" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Comprehensive <span className="text-ai-blue">AI Training Programs</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Industry-leading artificial intelligence courses designed for professionals, students, and organizations ready to embrace the AI-powered future.
            </p>
          </div>
          
          {/* Course Cards */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {/* AI for Professionals Card */}
            <Card className="bg-gradient-to-br from-ai-blue to-ai-electric text-white transform hover:scale-105 transition-all duration-300 shadow-xl border-0">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center mb-6">
                  <Briefcase className="text-2xl" />
                </div>
                <h3 className="text-2xl font-bold mb-4">AI for Professionals</h3>
                <p className="text-white/90 mb-6">Master AI tools and techniques for business applications, automation, and strategic decision-making.</p>
                <ul className="space-y-2 mb-8">
                  <li className="flex items-center"><Award className="mr-2 w-4 h-4" /> AI for Lawyers</li>
                  <li className="flex items-center"><Award className="mr-2 w-4 h-4" /> AI for Doctors</li>
                  <li className="flex items-center"><Award className="mr-2 w-4 h-4" /> AI for CA & Finance</li>
                  <li className="flex items-center"><Award className="mr-2 w-4 h-4" /> AI for HR Professionals</li>
                </ul>
                <Button className="w-full bg-white text-ai-blue py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors duration-300">
                  Explore Professional Tracks
                </Button>
              </CardContent>
            </Card>
            
            {/* Machine Learning Mastery */}
            <Card className="bg-gradient-to-br from-ai-green to-ai-emerald text-white transform hover:scale-105 transition-all duration-300 shadow-xl border-0">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center mb-6">
                  <Bot className="text-2xl" />
                </div>
                <h3 className="text-2xl font-bold mb-4">Machine Learning Mastery</h3>
                <p className="text-white/90 mb-6">Deep dive into algorithms, neural networks, and practical ML implementation for real-world projects.</p>
                <ul className="space-y-2 mb-8">
                  <li className="flex items-center"><Award className="mr-2 w-4 h-4" /> Supervised Learning</li>
                  <li className="flex items-center"><Award className="mr-2 w-4 h-4" /> Unsupervised Learning</li>
                  <li className="flex items-center"><Award className="mr-2 w-4 h-4" /> Deep Learning</li>
                  <li className="flex items-center"><Award className="mr-2 w-4 h-4" /> Neural Networks</li>
                </ul>
                <Button className="w-full bg-white text-ai-green py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors duration-300">
                  Start ML Journey
                </Button>
              </CardContent>
            </Card>
            
            {/* Generative AI & LLMs */}
            <Card className="bg-gradient-to-br from-ai-purple to-indigo-600 text-white transform hover:scale-105 transition-all duration-300 shadow-xl border-0">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center mb-6">
                  <Wand2 className="text-2xl" />
                </div>
                <h3 className="text-2xl font-bold mb-4">Generative AI & LLMs</h3>
                <p className="text-white/90 mb-6">Master ChatGPT, GPT-4, and custom AI model development for content creation and automation.</p>
                <ul className="space-y-2 mb-8">
                  <li className="flex items-center"><Award className="mr-2 w-4 h-4" /> Prompt Engineering</li>
                  <li className="flex items-center"><Award className="mr-2 w-4 h-4" /> Custom GPT Development</li>
                  <li className="flex items-center"><Award className="mr-2 w-4 h-4" /> AI Content Creation</li>
                  <li className="flex items-center"><Award className="mr-2 w-4 h-4" /> LLM Fine-tuning</li>
                </ul>
                <Button className="w-full bg-white text-ai-purple py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors duration-300">
                  Master Generative AI
                </Button>
              </CardContent>
            </Card>
          </div>
          
          {/* Quick Action Buttons */}
          <div className="grid md:grid-cols-3 gap-6">
            <a 
              href="https://nanoschool.in/ai/aipg/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-gray-100 hover:bg-gray-200 rounded-xl p-6 flex items-center justify-between transition-all duration-300 group"
            >
              <div>
                <h4 className="font-semibold text-gray-900 mb-1">AI Courses</h4>
                <p className="text-gray-600 text-sm">Comprehensive training programs</p>
              </div>
              <ChevronRight className="text-ai-blue group-hover:translate-x-2 transition-transform duration-300" />
            </a>
            
            <a 
              href="https://nanoschool.in/ai‑internship/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-gray-100 hover:bg-gray-200 rounded-xl p-6 flex items-center justify-between transition-all duration-300 group"
            >
              <div>
                <h4 className="font-semibold text-gray-900 mb-1">AI Internships</h4>
                <p className="text-gray-600 text-sm">Real-world experience programs</p>
              </div>
              <ChevronRight className="text-ai-blue group-hover:translate-x-2 transition-transform duration-300" />
            </a>
            
            <a 
              href="https://nanoschool.in/ai-courses/aiws/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-gray-100 hover:bg-gray-200 rounded-xl p-6 flex items-center justify-between transition-all duration-300 group"
            >
              <div>
                <h4 className="font-semibold text-gray-900 mb-1">AI Workshops</h4>
                <p className="text-gray-600 text-sm">Hands-on learning sessions</p>
              </div>
              <ChevronRight className="text-ai-blue group-hover:translate-x-2 transition-transform duration-300" />
            </a>
          </div>
        </div>
      </section>

      {/* Global Impact Analytics Section */}
      <section className="py-20 bg-gradient-to-br from-ai-blue via-ai-electric to-ai-purple">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Global <span className="text-ai-amber">AI Education Impact</span>
            </h2>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              Join a thriving community of AI learners from around the world. Our comprehensive programs have transformed careers across continents.
            </p>
          </div>
          
          {/* Analytics Grid */}
          <div className="grid lg:grid-cols-3 gap-8 mb-16">
            {/* Geographic Distribution */}
            <Card className="glassmorphism rounded-2xl border-white/20">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <Globe className="w-12 h-12 text-white mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-white mb-2">Global Reach</h3>
                  <p className="text-white/80">Students from 20+ countries</p>
                </div>
                
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-white/90 font-medium">India</span>
                    <span className="text-ai-amber font-bold">85%</span>
                  </div>
                  <div className="w-full bg-white/20 rounded-full h-2">
                    <div className="bg-ai-amber h-2 rounded-full" style={{ width: '85%' }}></div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-white/90 font-medium">USA & Europe</span>
                    <span className="text-ai-amber font-bold">8%</span>
                  </div>
                  <div className="w-full bg-white/20 rounded-full h-2">
                    <div className="bg-ai-amber h-2 rounded-full" style={{ width: '8%' }}></div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-white/90 font-medium">Other Countries</span>
                    <span className="text-ai-amber font-bold">7%</span>
                  </div>
                  <div className="w-full bg-white/20 rounded-full h-2">
                    <div className="bg-ai-amber h-2 rounded-full" style={{ width: '7%' }}></div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Education Levels */}
            <Card className="glassmorphism rounded-2xl border-white/20">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <GraduationCap className="w-12 h-12 text-white mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-white mb-2">Education Background</h3>
                  <p className="text-white/80">Diverse academic levels</p>
                </div>
                
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-white/90 font-medium">Post Graduate</span>
                    <span className="text-ai-amber font-bold">38%</span>
                  </div>
                  <div className="w-full bg-white/20 rounded-full h-2">
                    <div className="bg-ai-amber h-2 rounded-full" style={{ width: '38%' }}></div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-white/90 font-medium">Graduate</span>
                    <span className="text-ai-amber font-bold">31%</span>
                  </div>
                  <div className="w-full bg-white/20 rounded-full h-2">
                    <div className="bg-ai-amber h-2 rounded-full" style={{ width: '31%' }}></div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-white/90 font-medium">Ph.D & Research</span>
                    <span className="text-ai-amber font-bold">18%</span>
                  </div>
                  <div className="w-full bg-white/20 rounded-full h-2">
                    <div className="bg-ai-amber h-2 rounded-full" style={{ width: '18%' }}></div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-white/90 font-medium">Diploma & Others</span>
                    <span className="text-ai-amber font-bold">13%</span>
                  </div>
                  <div className="w-full bg-white/20 rounded-full h-2">
                    <div className="bg-ai-amber h-2 rounded-full" style={{ width: '13%' }}></div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Experience Levels */}
            <Card className="glassmorphism rounded-2xl border-white/20">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <Briefcase className="w-12 h-12 text-white mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-white mb-2">Experience Levels</h3>
                  <p className="text-white/80">From beginners to experts</p>
                </div>
                
                <div className="space-y-6">
                  <div className="text-center">
                    <div className="text-4xl font-bold text-ai-amber mb-2">83%</div>
                    <div className="text-white/90 font-medium">Fresh Professionals</div>
                    <div className="text-white/70 text-sm">Starting their AI journey</div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-4xl font-bold text-ai-amber mb-2">17%</div>
                    <div className="text-white/90 font-medium">Experienced</div>
                    <div className="text-white/70 text-sm">Advancing AI skills</div>
                  </div>
                  
                  <div className="mt-6 p-4 bg-white/10 rounded-xl">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-white mb-1">13,534+</div>
                      <div className="text-white/80 text-sm">Total Participants Trained</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Top Countries */}
          <Card className="glassmorphism rounded-2xl border-white/20">
            <CardContent className="p-8">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-white mb-4">Top Countries by Participation</h3>
                <p className="text-white/80">Our global community spans continents</p>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
                    <span className="text-2xl">🇮🇳</span>
                  </div>
                  <div className="text-white font-bold">India</div>
                  <div className="text-ai-amber font-semibold">11,200+</div>
                </div>
                
                <div className="text-center">
                  <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
                    <span className="text-2xl">🇵🇰</span>
                  </div>
                  <div className="text-white font-bold">Pakistan</div>
                  <div className="text-ai-amber font-semibold">850+</div>
                </div>
                
                <div className="text-center">
                  <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
                    <span className="text-2xl">🇺🇸</span>
                  </div>
                  <div className="text-white font-bold">USA</div>
                  <div className="text-ai-amber font-semibold">650+</div>
                </div>
                
                <div className="text-center">
                  <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
                    <span className="text-2xl">🇸🇦</span>
                  </div>
                  <div className="text-white font-bold">Saudi Arabia</div>
                  <div className="text-ai-amber font-semibold">420+</div>
                </div>
                
                <div className="text-center">
                  <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
                    <span className="text-2xl">🌍</span>
                  </div>
                  <div className="text-white font-bold">Others</div>
                  <div className="text-ai-amber font-semibold">400+</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Workshops Section */}
      <section id="workshops" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Hands-on <span className="text-ai-blue">AI Workshops</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Interactive learning experiences designed to give you practical AI skills through real-world projects and expert guidance.
            </p>
          </div>
          
          {/* Workshop Showcase Container */}
          <Card className="bg-white rounded-2xl shadow-xl mb-12">
            <CardContent className="p-8">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Featured Workshops</h3>
                <p className="text-gray-600">Interactive AI workshops and training sessions</p>
              </div>
              
              {/* Placeholder for Formidable Shortcode */}
              <div className="min-h-96 bg-gray-50 rounded-xl border-2 border-dashed border-gray-300 flex items-center justify-center">
                <div className="text-center">
                  <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500 text-lg font-medium mb-2">Workshop Showcase</p>
                  <p className="text-gray-400 mb-4">[display-frm-data id=67204 dptm=AI forlaw="AI For Lawyers"]</p>
                  <p className="text-sm text-gray-400">Dynamic workshop data will be displayed here via Formidable forms</p>
                </div>
              </div>
              
              <div className="text-center mt-8">
                <a 
                  href="https://nanoschool.in/ai-courses/aiws/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center bg-gradient-to-r from-ai-blue to-ai-purple text-white px-8 py-3 rounded-lg font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-300"
                >
                  View All Workshops
                  <ExternalLink className="ml-2 w-4 h-4" />
                </a>
              </div>
            </CardContent>
          </Card>
          
          {/* Workshop Benefits */}
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-ai-blue to-ai-purple rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="text-white text-2xl" />
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-4">Interactive Learning</h4>
              <p className="text-gray-600">Engage in hands-on projects and real-time collaboration with industry experts and peers.</p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-ai-green to-ai-emerald rounded-full flex items-center justify-center mx-auto mb-6">
                <Award className="text-white text-2xl" />
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-4">Industry Certification</h4>
              <p className="text-gray-600">Earn recognized certifications that validate your AI skills and boost your career prospects.</p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-ai-purple to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <Globe className="text-white text-2xl" />
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-4">Professional Network</h4>
              <p className="text-gray-600">Connect with like-minded professionals and build valuable relationships in the AI community.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Expert Mentors Section */}
      <section id="mentors" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Learn from <span className="text-ai-blue">AI Experts</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Get personalized guidance from industry-leading AI professionals with years of real-world experience in machine learning and artificial intelligence.
            </p>
          </div>
          
          {/* Mentors Showcase Container */}
          <Card className="bg-gradient-to-br from-gray-50 to-blue-50 rounded-2xl shadow-xl mb-12">
            <CardContent className="p-8">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Our AI Mentors</h3>
                <p className="text-gray-600">Meet our team of experienced artificial intelligence professionals</p>
              </div>
              
              {/* Placeholder for Formidable Shortcode */}
              <div className="min-h-96 bg-white rounded-xl border-2 border-dashed border-gray-300 flex items-center justify-center">
                <div className="text-center">
                  <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500 text-lg font-medium mb-2">Expert Mentors</p>
                  <p className="text-gray-400 mb-4">Formidable shortcode for mentor profiles will be embedded here</p>
                  <p className="text-sm text-gray-400">Dynamic mentor data from WordPress database</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Mentor Benefits */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center bg-gray-50">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-br from-ai-blue to-ai-purple rounded-full flex items-center justify-center mx-auto mb-4">
                  <GraduationCap className="text-white text-xl" />
                </div>
                <h4 className="font-bold text-gray-900 mb-2">PhD Researchers</h4>
                <p className="text-gray-600 text-sm">Leading academics in AI and machine learning</p>
              </CardContent>
            </Card>
            
            <Card className="text-center bg-gray-50">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-br from-ai-green to-ai-emerald rounded-full flex items-center justify-center mx-auto mb-4">
                  <Briefcase className="text-white text-xl" />
                </div>
                <h4 className="font-bold text-gray-900 mb-2">Industry Veterans</h4>
                <p className="text-gray-600 text-sm">Senior professionals from tech giants</p>
              </CardContent>
            </Card>
            
            <Card className="text-center bg-gray-50">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-br from-ai-purple to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Brain className="text-white text-xl" />
                </div>
                <h4 className="font-bold text-gray-900 mb-2">Innovation Leaders</h4>
                <p className="text-gray-600 text-sm">Founders and CTOs of AI startups</p>
              </CardContent>
            </Card>
            
            <Card className="text-center bg-gray-50">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-br from-ai-amber to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="text-white text-xl" />
                </div>
                <h4 className="font-bold text-gray-900 mb-2">Published Authors</h4>
                <p className="text-gray-600 text-sm">Contributors to AI research papers</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Success Stories Section */}
      <section id="testimonials" className="py-20 bg-gradient-to-br from-ai-blue via-ai-purple to-indigo-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Success Stories from <span className="text-ai-amber">AI Professionals</span>
            </h2>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              Discover how our students transformed their careers and organizations through comprehensive AI education and training programs.
            </p>
          </div>
          
          {/* Testimonials Showcase Container */}
          <Card className="glassmorphism rounded-2xl border-white/20 mb-12">
            <CardContent className="p-8">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-white mb-4">Student Testimonials</h3>
                <p className="text-white/80">Real feedback from our AI course graduates</p>
              </div>
              
              {/* Placeholder for Formidable Shortcode */}
              <div className="min-h-96 bg-white/10 rounded-xl border-2 border-dashed border-white/30 flex items-center justify-center">
                <div className="text-center">
                  <Users className="w-16 h-16 text-white/60 mx-auto mb-4" />
                  <p className="text-white text-lg font-medium mb-2">Student Testimonials</p>
                  <p className="text-white/70 mb-4">Formidable shortcode for testimonials will be embedded here</p>
                  <p className="text-sm text-white/60">Dynamic testimonial carousel from WordPress database</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Impact Numbers */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <Card className="glassmorphism rounded-xl border-white/20">
              <CardContent className="p-6">
                <div className="text-4xl font-bold text-white mb-2">94%</div>
                <div className="text-white/80 text-sm">Career Advancement</div>
              </CardContent>
            </Card>
            <Card className="glassmorphism rounded-xl border-white/20">
              <CardContent className="p-6">
                <div className="text-4xl font-bold text-white mb-2">87%</div>
                <div className="text-white/80 text-sm">Salary Increase</div>
              </CardContent>
            </Card>
            <Card className="glassmorphism rounded-xl border-white/20">
              <CardContent className="p-6">
                <div className="text-4xl font-bold text-white mb-2">92%</div>
                <div className="text-white/80 text-sm">Job Satisfaction</div>
              </CardContent>
            </Card>
            <Card className="glassmorphism rounded-xl border-white/20">
              <CardContent className="p-6">
                <div className="text-4xl font-bold text-white mb-2">96%</div>
                <div className="text-white/80 text-sm">Would Recommend</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Programs Overview Section */}
      <section id="programs" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Comprehensive <span className="text-ai-blue">AI Program Catalog</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Explore our full range of artificial intelligence training programs, certifications, and specialized courses designed for different industries and career levels.
            </p>
          </div>
          
          {/* Program Categories */}
          <div className="grid lg:grid-cols-2 gap-12 mb-16">
            {/* Professional AI Programs */}
            <Card className="bg-gradient-to-br from-gray-50 to-blue-50 rounded-2xl">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Professional AI Training</h3>
                <div className="space-y-4">
                  <a 
                    href="https://nanoschool.in/ai/ai-for-lawyers/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-4 bg-white rounded-lg hover:shadow-md transition-all duration-300 group"
                  >
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-gradient-to-br from-ai-blue to-ai-purple rounded-lg flex items-center justify-center mr-4">
                        <Gavel className="text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">AI for Lawyers</h4>
                        <p className="text-gray-600 text-sm">Legal AI tools and automation</p>
                      </div>
                    </div>
                    <ChevronRight className="text-ai-blue group-hover:translate-x-2 transition-transform duration-300" />
                  </a>
                  
                  <a 
                    href="https://nanoschool.in/ai/ai-for-doctors/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-4 bg-white rounded-lg hover:shadow-md transition-all duration-300 group"
                  >
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-gradient-to-br from-ai-green to-ai-emerald rounded-lg flex items-center justify-center mr-4">
                        <Stethoscope className="text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">AI for Doctors</h4>
                        <p className="text-gray-600 text-sm">Medical AI and diagnostics</p>
                      </div>
                    </div>
                    <ChevronRight className="text-ai-green group-hover:translate-x-2 transition-transform duration-300" />
                  </a>
                  
                  <a 
                    href="https://nanoschool.in/ai/ai-for-teachers/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-4 bg-white rounded-lg hover:shadow-md transition-all duration-300 group"
                  >
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-gradient-to-br from-ai-purple to-indigo-600 rounded-lg flex items-center justify-center mr-4">
                        <Presentation className="text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">AI for Teachers</h4>
                        <p className="text-gray-600 text-sm">Educational AI and EdTech</p>
                      </div>
                    </div>
                    <ChevronRight className="text-ai-purple group-hover:translate-x-2 transition-transform duration-300" />
                  </a>
                  
                  <a 
                    href="https://nanoschool.in/ai/ai-for-ca/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-4 bg-white rounded-lg hover:shadow-md transition-all duration-300 group"
                  >
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-gradient-to-br from-ai-amber to-orange-500 rounded-lg flex items-center justify-center mr-4">
                        <Calculator className="text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">AI for Chartered Accountants</h4>
                        <p className="text-gray-600 text-sm">Financial AI and automation</p>
                      </div>
                    </div>
                    <ChevronRight className="text-ai-amber group-hover:translate-x-2 transition-transform duration-300" />
                  </a>
                  
                  <a 
                    href="https://nanoschool.in/ai/ai-for-hr-professionals/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-4 bg-white rounded-lg hover:shadow-md transition-all duration-300 group"
                  >
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-rose-500 rounded-lg flex items-center justify-center mr-4">
                        <Users className="text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">AI for HR Professionals</h4>
                        <p className="text-gray-600 text-sm">HR automation and analytics</p>
                      </div>
                    </div>
                    <ChevronRight className="text-pink-500 group-hover:translate-x-2 transition-transform duration-300" />
                  </a>
                </div>
              </CardContent>
            </Card>
            
            {/* Technical AI Programs */}
            <Card className="bg-gradient-to-br from-gray-50 to-purple-50 rounded-2xl">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Technical AI Specializations</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-white rounded-lg">
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-gradient-to-br from-ai-blue to-ai-purple rounded-lg flex items-center justify-center mr-4">
                        <Cog className="text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">AI for Engineers</h4>
                        <p className="text-gray-600 text-sm">Technical AI implementation</p>
                      </div>
                    </div>
                    <span className="text-ai-amber font-semibold">Coming Soon</span>
                  </div>
                  
                  <a 
                    href="https://nanoschool.in/ai/ai-in-health-care/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-4 bg-white rounded-lg hover:shadow-md transition-all duration-300 group"
                  >
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-gradient-to-br from-ai-green to-ai-emerald rounded-lg flex items-center justify-center mr-4">
                        <Heart className="text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">AI in Healthcare</h4>
                        <p className="text-gray-600 text-sm">Medical AI applications</p>
                      </div>
                    </div>
                    <ChevronRight className="text-ai-green group-hover:translate-x-2 transition-transform duration-300" />
                  </a>
                  
                  <div className="flex items-center justify-between p-4 bg-white rounded-lg">
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-gradient-to-br from-ai-purple to-indigo-600 rounded-lg flex items-center justify-center mr-4">
                        <Database className="text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Data Science & AI</h4>
                        <p className="text-gray-600 text-sm">Advanced analytics with AI</p>
                      </div>
                    </div>
                    <span className="text-ai-amber font-semibold">Coming Soon</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-white rounded-lg">
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-gradient-to-br from-ai-amber to-orange-500 rounded-lg flex items-center justify-center mr-4">
                        <Eye className="text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Computer Vision</h4>
                        <p className="text-gray-600 text-sm">Image and video AI</p>
                      </div>
                    </div>
                    <span className="text-ai-amber font-semibold">Coming Soon</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-white rounded-lg">
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-rose-500 rounded-lg flex items-center justify-center mr-4">
                        <MessageSquare className="text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Natural Language Processing</h4>
                        <p className="text-gray-600 text-sm">Text and language AI</p>
                      </div>
                    </div>
                    <span className="text-ai-amber font-semibold">Coming Soon</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Quick Links */}
          <div className="text-center">
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <a 
                href="https://nanoschool.in/all-programs/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-gradient-to-r from-ai-blue to-ai-purple text-white py-4 px-6 rounded-lg font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-300 inline-flex items-center justify-center"
              >
                <List className="mr-2" />
                View All Programs
              </a>
              
              <a 
                href="https://nanoschool.in/faqs/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-gradient-to-r from-ai-green to-ai-emerald text-white py-4 px-6 rounded-lg font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-300 inline-flex items-center justify-center"
              >
                <HelpCircle className="mr-2" />
                FAQs
              </a>
              
              <Button className="bg-gradient-to-r from-ai-purple to-indigo-600 text-white py-4 px-6 rounded-lg font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-300">
                <Phone className="mr-2" />
                Contact Advisor
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-20 bg-gradient-to-r from-ai-blue via-ai-purple to-indigo-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Ready to Start Your <span className="text-ai-amber">AI Journey?</span>
          </h2>
          <p className="text-xl text-white mb-8 max-w-2xl mx-auto font-medium">
            Join thousands of professionals who have transformed their careers with our comprehensive AI education programs. Start learning today and become an AI expert tomorrow.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-white text-ai-blue px-8 py-4 rounded-lg font-bold text-lg hover:bg-gray-100 transform hover:scale-105 transition-all duration-300 shadow-xl">
              <GraduationCap className="mr-2" />
              Enroll Now
            </Button>
            <Button 
              variant="ghost"
              className="glassmorphism text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-white/20 transform hover:scale-105 transition-all duration-300"
            >
              <Calendar className="mr-2" />
              Schedule Consultation
            </Button>
          </div>
          
          <div className="mt-12 text-white/80">
            <p className="mb-2">🎓 50,000+ Students Trained | 🌍 95+ Countries | ⭐ 98% Success Rate</p>
            <p className="text-sm">Join the global AI education revolution with NSTC</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            {/* Company Info */}
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-ai-blue to-ai-purple rounded-lg flex items-center justify-center">
                  <Brain className="text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-bold">NSTC</h3>
                  <p className="text-xs text-gray-400">AI Education Hub</p>
                </div>
              </div>
              <p className="text-gray-400 text-sm mb-4">
                Leading provider of artificial intelligence education, training, and certification programs for professionals worldwide.
              </p>
            </div>
            
            {/* Quick Links */}
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                <li><button onClick={() => scrollToSection('courses')} className="text-gray-400 hover:text-white transition-colors duration-300">AI Courses</button></li>
                <li><button onClick={() => scrollToSection('workshops')} className="text-gray-400 hover:text-white transition-colors duration-300">Workshops</button></li>
                <li><button onClick={() => scrollToSection('mentors')} className="text-gray-400 hover:text-white transition-colors duration-300">Expert Mentors</button></li>
                <li><button onClick={() => scrollToSection('testimonials')} className="text-gray-400 hover:text-white transition-colors duration-300">Success Stories</button></li>
                <li><a href="https://nanoschool.in/all-programs/" className="text-gray-400 hover:text-white transition-colors duration-300">All Programs</a></li>
              </ul>
            </div>
            
            {/* Professional Programs */}
            <div>
              <h4 className="text-lg font-semibold mb-4">Professional AI</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="https://nanoschool.in/ai/ai-for-lawyers/" className="text-gray-400 hover:text-white transition-colors duration-300">AI for Lawyers</a></li>
                <li><a href="https://nanoschool.in/ai/ai-for-doctors/" className="text-gray-400 hover:text-white transition-colors duration-300">AI for Doctors</a></li>
                <li><a href="https://nanoschool.in/ai/ai-for-teachers/" className="text-gray-400 hover:text-white transition-colors duration-300">AI for Teachers</a></li>
                <li><a href="https://nanoschool.in/ai/ai-for-ca/" className="text-gray-400 hover:text-white transition-colors duration-300">AI for CA</a></li>
                <li><a href="https://nanoschool.in/ai/ai-for-hr-professionals/" className="text-gray-400 hover:text-white transition-colors duration-300">AI for HR</a></li>
              </ul>
            </div>
            
            {/* Contact Info */}
            <div>
              <h4 className="text-lg font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>📧 info@nanoschool.in</li>
                <li>📞 +91 XXX XXX XXXX</li>
                <li>🌐 www.nanoschool.in</li>
                <li><a href="https://nanoschool.in/faqs/" className="hover:text-white transition-colors duration-300">❓ FAQs & Support</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-700 pt-8 text-center">
            <p className="text-gray-400 text-sm">
              © 2025 NSTC - Nano Science and Technology Consortium. All rights reserved. | 
              <a href="#" className="hover:text-white transition-colors duration-300 ml-2">Privacy Policy</a> | 
              <a href="#" className="hover:text-white transition-colors duration-300 ml-2">Terms of Service</a>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
