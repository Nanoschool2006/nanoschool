interface SEOHeadProps {
  title?: string;
  description?: string;
  keywords?: string;
  ogImage?: string;
  url?: string;
}

export function SEOHead({
  title = "NSTC AI Education | Advanced Artificial Intelligence Courses & Training 2025",
  description = "Master AI with NSTC's comprehensive artificial intelligence courses, workshops & training programs. Expert mentors, industry certifications, and hands-on learning for professionals in 2025.",
  keywords = "AI courses, artificial intelligence training, machine learning certification, AI for professionals, generative AI course, AI education, deep learning, NSTC",
  ogImage = "https://images.unsplash.com/photo-1677442136019-21780ecad995?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=630",
  url = "https://nanoschool.in"
}: SEOHeadProps) {
  // This would be implemented with react-helmet or similar in a real app
  // For now, we'll return null since the SEO tags are in the HTML head
  return null;
}
